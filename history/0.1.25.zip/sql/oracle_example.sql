select 'jon', 'roberts' FROM DUAL
union all
select 'JON', 'ROBERTS' FROM DUAL
