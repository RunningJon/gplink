tableName=public.edw_example
columns=i int, fname text, lname text
