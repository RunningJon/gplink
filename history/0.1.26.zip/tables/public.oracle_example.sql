tableName=public.oracle_example
columns=first_name text, last_name text
