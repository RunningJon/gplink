select * from gplink_demo.oracle;
