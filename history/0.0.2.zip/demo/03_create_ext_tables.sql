select gplink.fn_create_ext_table(1);
select gplink.fn_create_ext_table(2);
