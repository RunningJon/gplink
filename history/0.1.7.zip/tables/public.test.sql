tableName=public.test
columns=first_name text, last_name text
