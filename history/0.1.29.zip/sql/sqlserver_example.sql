select 'jon', 'roberts'
union all
select 'JON', 'ROBERTS'
