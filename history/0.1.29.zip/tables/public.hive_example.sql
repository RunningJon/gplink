tableName=public.hive_example
columns=first_name text, last_name text
