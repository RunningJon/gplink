select *
from customer;
